libmpv r23 for windows-x86_64: LGPL-3.0-or-later

This build of libmpv is LGPL, version 3 or later (the LGPLv3 is a set of
permissions on top of the GPLv3, so both texts are here). It lets an app
link the library whatever its own license, on its conditions, among them:
ship these texts, say that the app uses libmpv and that libmpv is under
the LGPL, provide the source of this library (see Source below), and let
the user replace it with one built from modified source. libmpv is a
separate dynamic library or module on every platform. The texts are the terms.

Components, and the license files of each one in the directory of its name:
  libmpv-scripts the build scripts and the patches of this repo: LICENSE (BSD-3-Clause),
                 NOTICE (its files under the LGPL, MIT and MPL-2.0), LICENSE.LGPL-2.1;
                 what a patch changes in mpv or FFmpeg is under their license
  mpv            mpv-0.41.0: LICENSE.LGPL, Copyright
  ffmpeg         ffmpeg-8.1.1: COPYING.LGPLv3, COPYING.GPLv3, LICENSE.md
  openssl        openssl-3.5.6: LICENSE.txt
  libplacebo     libplacebo-git: LICENSE
  libxml2        libxml2-2.14.6: Copyright
  zlib           zlib-1.3.2: LICENSE
  bzip2          bzip2-1.0.8: LICENSE
  xz             xz-5.8.3: COPYING, COPYING.0BSD, COPYING.GPLv2, COPYING.GPLv3, COPYING.LGPLv2.1
  libiconv       libiconv-1.18: COPYING, COPYING.LIB
  speexdsp       speexdsp-SpeexDSP-1.2.1: COPYING
  winpthreads    mingw-w64 winpthreads of the toolchain: COPYING
  mingw-w64-crt  mingw-w64 runtime (CRT) of the toolchain: COPYING.MinGW-w64-runtime.txt
  libsmb2        libsmb2: COPYING, LICENCE-LGPL-2.1.txt
  mozilla-ca     the Mozilla CA bundle (MPL-2.0)

Source: https://github.com/ales-drnz/libmpv-scripts at commit f65c411ddd37562e65e0f8d1750694cda87564d1
builds this library from the upstream sources below, pinned by SHA-256 (tarballs)
or commit (git tags) in scripts/shared/_sources.sha256, with the patches under
patches/ of that commit:
  ee21092a5ee427353392360929dc64645c54479aefdb5babc5cfbb5fad626209  https://github.com/mpv-player/mpv/archive/refs/tags/v0.41.0.tar.gz
  b6863adde98898f42602017462871b5f6333e65aec803fdd7a6308639c52edf3  https://ffmpeg.org/releases/ffmpeg-8.1.1.tar.xz
  deae7c80cba99c4b4f940ecadb3c3338b13cb77418409238e57d7f31f2a3b736  https://github.com/openssl/openssl/releases/download/openssl-3.5.6/openssl-3.5.6.tar.gz
  64c1954570f1cd57f8570a57e51fb0249b57bb90  https://code.videolan.org/videolan/libplacebo.git#v6.338.2
  7ce458a0affeb83f0b55f1f4f9e0e55735dbfc1a9de124ee86fb4a66b597203a  https://download.gnome.org/sources/libxml2/2.14/libxml2-2.14.6.tar.xz
  bb329a0a2cd0274d05519d61c667c062e06990d72e125ee2dfa8de64f0119d16  https://github.com/madler/zlib/releases/download/v1.3.2/zlib-1.3.2.tar.gz
  ab5a03176ee106d3f0fa90e381da478ddae405918153cca248e682cd0c4a2269  https://sourceware.org/pub/bzip2/bzip2-1.0.8.tar.gz
  3d3a1b973af218114f4f889bbaa2f4c037deaae0c8e815eec381c3d546b974a0  https://tukaani.org/xz/xz-5.8.3.tar.gz
  3b08f5f4f9b4eb82f151a7040bfd6fe6c6fb922efe4b1659c66ea933276965e8  https://ftp.gnu.org/pub/gnu/libiconv/libiconv-1.18.tar.gz
  d17ca363654556a4ff1d02cc13d9eb1fc5a8642c90b40bd54ce266c3807b91a7  https://github.com/xiph/speexdsp/archive/refs/tags/SpeexDSP-1.2.1.tar.gz
  b9444620ba7f26ed216a663bf2282a9427e36c36  https://github.com/sahlberg/libsmb2.git#v6.0.0
